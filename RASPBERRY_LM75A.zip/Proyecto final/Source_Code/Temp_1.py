import smbus
import time
import threading

I2C_TMP_LM75_ADRESS = 0x48              
LM75_TMP_BYTE = 0x00                
i2c = smbus.SMBus(1)

def getTemp():
    temp = ""
    raw = i2c.read_i2c_block_data(I2C_TMP_LM75_ADRESS, LM75_TMP_BYTE)
    tempMsb = raw[0]
    tempLsb = raw[1]
    temp = (((tempMsb << 8) | tempLsb) >>7) * 0.5
    if temp > 125:
        temp = temp - 256
    return(temp)

while True:
    temp = getTemp()
    print("Temperatura: "+ str(getTemp()) + " °C")
    time.sleep(0.1)

t = threading.Thread(target = getTemp)
t2 = threading.Thread(target = getTemp)
t3 = threading.Thread(target = getTemp)